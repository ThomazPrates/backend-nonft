
export const jwtConstants = {
  secret: 'ASDA213GT1FV231GT23',
};
